import os
import qrcode

# Website used for this test (different from Google and Python.org)
website_url = "https://www.wikipedia.org"

folder_name = "generated_qrcodes"
file_name = "wikipedia_qr.png"
full_path = os.path.join(folder_name, file_name)
os.makedirs(folder_name, exist_ok=True)

qr = qrcode.QRCode(
    version=None,
    error_correction=qrcode.constants.ERROR_CORRECT_H,
    box_size=10,
    border=4,
)
qr.add_data(website_url)
qr.make(fit=True)

img = qr.make_image(fill_color="black", back_color="lightyellow")
img.save(full_path)

print(f"QR code saved successfully to: {os.path.abspath(full_path)}")
print(f"Encoded website: {website_url}")
