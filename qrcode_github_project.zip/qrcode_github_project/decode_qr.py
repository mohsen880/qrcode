from pathlib import Path
from PIL import Image
from pyzbar.pyzbar import decode

image_path = Path("generated_qrcodes/wikipedia_qr.png")

if not image_path.exists():
    raise FileNotFoundError(
        f"QR image not found: {image_path}. Run generate_qr.py first."
    )

img = Image.open(image_path)
decoded_objects = decode(img)

if not decoded_objects:
    print("No QR code was detected.")
else:
    for obj in decoded_objects:
        print(f"Type: {obj.type}")
        print(f"Data: {obj.data.decode('utf-8')}")
