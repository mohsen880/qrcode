import qrcode

# Generate a simple QR code for a website
website_url = "https://www.wikipedia.org"
img = qrcode.make(website_url)
img.save("generated_qrcodes/simple_qr.png")

print(f"QR code created for: {website_url}")
print("Saved to: generated_qrcodes/simple_qr.png")
